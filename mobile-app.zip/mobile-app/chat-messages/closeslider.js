var cross = document.getElementById("cross");
var slider = document.getElementById("slider");
   





function openit(e){
    slider.style.left = "0%";
}


function closeit(d) {
    slider.style.left = "-87%";
       
        
    };